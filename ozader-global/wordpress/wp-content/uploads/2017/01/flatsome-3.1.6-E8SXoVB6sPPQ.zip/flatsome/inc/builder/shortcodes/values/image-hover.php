<?php 

return array(
    '' => 'None',
    'zoom' => 'Zoom',
    'zoom-long' => 'Zoom Long',
    'zoom-fade' => 'Zoom Fade',
    'blur' => 'Blur',
    'fade-in' => 'Fade In',
    'fade-out' => 'Fade Out',
    'glow' => 'Glow',
    'color' => 'Add Color',
    'grayscale' => 'Grayscale',
    'overlay-add' => 'Add Overlay',
    'overlay-remove' => 'Remove Overlay',
    'overlay-add-50' => 'Add Overlay (50%)',
    'overlay-remove-50' => 'Remove Overlay (50%)',
);